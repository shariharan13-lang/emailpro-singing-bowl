import os
import re
import sqlite3
import smtplib
import csv
import io
from email.message import EmailMessage
from datetime import datetime

from flask import Flask, request, jsonify, render_template, g, send_from_directory, Response
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
DB_PATH = os.path.join(DATA_DIR, "emailpro.db")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024  # 20 MB uploads

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business TEXT NOT NULL,
            owner TEXT,
            email TEXT NOT NULL,
            phone TEXT,
            country TEXT,
            source TEXT,
            score INTEGER DEFAULT 0,
            contacted TEXT DEFAULT 'No',
            website TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """
    )
    conn.commit()

    cur = conn.execute("SELECT COUNT(*) AS c FROM leads")
    count = cur.fetchone()[0]
    if count == 0:
        sample_leads = [
            (
                "Soundtopia: Worlds Best Himalayan Singing Bowls and Crystal Singing Bowls",
                "",
                "info@soundtopia.com",
                "15691958772907",
                "USA",
                "business_website",
                100,
                "No",
                "https://www.soundtopia.com",
            ),
            (
                "Best Himalaya",
                "",
                "business@besthimalaya.com",
                "17996883558494",
                "USA",
                "business_website",
                100,
                "No",
                "https://www.besthimalaya.com",
            ),
            (
                "Kathmandu Singing Bowl Centre",
                "Ramesh Shakya",
                "info@ktmsingingbowl.com",
                "9779841234567",
                "Nepal",
                "directory",
                85,
                "No",
                "https://www.ktmsingingbowl.com",
            ),
            (
                "Himalayan Sound Imports",
                "Tenzin Norbu",
                "sales@himalayansoundimports.co.uk",
                "447911123456",
                "UK",
                "business_website",
                72,
                "No",
                "https://www.himalayansoundimports.co.uk",
            ),
        ]
        conn.executemany(
            """
            INSERT INTO leads (business, owner, email, phone, country, source, score, contacted, website)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            sample_leads,
        )
        conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Settings helpers (stores catalog filename, etc.)
# ---------------------------------------------------------------------------

def get_setting(key, default=None):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Email helpers
# ---------------------------------------------------------------------------

def smtp_configured():
    return all(
        os.environ.get(k)
        for k in ("SMTP_HOST", "SMTP_PORT", "SMTP_USERNAME", "SMTP_PASSWORD", "MAIL_FROM")
    )


def render_template_vars(template, lead):
    business = lead["business"] or ""
    owner = lead["owner"] or business or "there"
    whatsapp = os.environ.get("WHATSAPP_NUMBER", "+8770000000000")
    unsubscribe = f"{request.url_root.rstrip('/')}/unsubscribe?email={lead['email']}"
    replacements = {
        "{{ownerName}}": owner,
        "{{businessName}}": business,
        "{{whatsAppNumber}}": whatsapp,
        "{{unsubscribeUrl}}": unsubscribe,
    }
    result = template
    for key, val in replacements.items():
        result = result.replace(key, val)
    return result


def send_email(to_email, subject, html_body, attachment_path=None):
    if not smtp_configured():
        return False, "Demo mode: SMTP is not configured."

    host = os.environ["SMTP_HOST"]
    port = int(os.environ["SMTP_PORT"])
    username = os.environ["SMTP_USERNAME"]
    password = os.environ["SMTP_PASSWORD"]
    mail_from = os.environ["MAIL_FROM"]

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = mail_from
    msg["To"] = to_email
    text_fallback = re.sub("<[^<]+?>", "", html_body)
    msg.set_content(text_fallback)
    msg.add_alternative(html_body, subtype="html")

    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, "rb") as f:
            data = f.read()
        msg.add_attachment(
            data,
            maintype="application",
            subtype="pdf",
            filename=os.path.basename(attachment_path),
        )

    try:
        with smtplib.SMTP(host, port, timeout=20) as server:
            server.starttls()
            server.login(username, password)
            server.send_message(msg)
        return True, "sent"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


# ---------------------------------------------------------------------------
# Page routes
# ---------------------------------------------------------------------------

@app.route("/")
def store():
    return render_template("store.html")


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)


@app.route("/unsubscribe")
def unsubscribe():
    email = request.args.get("email", "")
    return f"<h2 style='font-family:sans-serif;padding:40px'>{email or 'You'} have been unsubscribed.</h2>"


# ---------------------------------------------------------------------------
# API: leads CRUD
# ---------------------------------------------------------------------------

def lead_to_dict(row):
    return {
        "id": row["id"],
        "business": row["business"],
        "owner": row["owner"],
        "email": row["email"],
        "phone": row["phone"],
        "country": row["country"],
        "source": row["source"],
        "score": row["score"],
        "contacted": row["contacted"],
        "website": row["website"],
    }


@app.route("/api/leads", methods=["GET"])
def api_get_leads():
    db = get_db()
    rows = db.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()
    return jsonify([lead_to_dict(r) for r in rows]), 200


@app.route("/api/leads/<int:lead_id>", methods=["GET"])
def api_get_lead(lead_id):
    db = get_db()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if not row:
        return jsonify({"error": "Lead not found"}), 404
    return jsonify(lead_to_dict(row)), 200


@app.route("/api/leads", methods=["POST"])
def api_create_lead():
    data = request.get_json(silent=True) or {}
    business = (data.get("business") or "").strip()
    email = (data.get("email") or "").strip()
    if not business or not email:
        return jsonify({"error": "business and email are required"}), 400

    db = get_db()
    cur = db.execute(
        """
        INSERT INTO leads (business, owner, email, phone, country, source, score, contacted, website)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            business,
            data.get("owner", ""),
            email,
            data.get("phone", ""),
            data.get("country", ""),
            data.get("source", ""),
            int(data.get("score", 0) or 0),
            data.get("contacted", "No"),
            data.get("website", ""),
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(lead_to_dict(row)), 201


@app.route("/api/leads/<int:lead_id>", methods=["PUT"])
def api_update_lead(lead_id):
    db = get_db()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if not row:
        return jsonify({"error": "Lead not found"}), 404

    data = request.get_json(silent=True) or {}
    fields = ["business", "owner", "email", "phone", "country", "source", "score", "contacted", "website"]
    updates = {f: data[f] for f in fields if f in data}
    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [lead_id]
    db.execute(f"UPDATE leads SET {set_clause} WHERE id = ?", values)
    db.commit()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    return jsonify(lead_to_dict(row)), 200


@app.route("/api/leads/<int:lead_id>", methods=["DELETE"])
def api_delete_lead(lead_id):
    db = get_db()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if not row:
        return jsonify({"error": "Lead not found"}), 404
    db.execute("DELETE FROM leads WHERE id = ?", (lead_id,))
    db.commit()
    return jsonify({"message": "Lead deleted", "id": lead_id}), 200


# ---------------------------------------------------------------------------
# API: catalog upload
# ---------------------------------------------------------------------------

@app.route("/api/upload-catalog", methods=["POST"])
def api_upload_catalog():
    if "file" not in request.files:
        return jsonify({"error": "No file part named 'file'"}), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400
    if not file.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Only PDF files are allowed"}), 400

    filename = secure_filename(file.filename)
    if not filename:
        filename = "catalog.pdf"
    save_path = os.path.join(UPLOAD_DIR, "catalog.pdf")
    file.save(save_path)
    set_setting("catalog_filename", filename)

    return (
        jsonify(
            {
                "message": "Catalog uploaded",
                "filename": filename,
                "url": f"{request.url_root.rstrip('/')}/uploads/catalog.pdf",
            }
        ),
        200,
    )


@app.route("/api/catalog-status", methods=["GET"])
def api_catalog_status():
    exists = os.path.exists(os.path.join(UPLOAD_DIR, "catalog.pdf"))
    filename = get_setting("catalog_filename", "catalog.pdf") if exists else None
    return jsonify(
        {
            "uploaded": exists,
            "filename": filename,
            "url": f"{request.url_root.rstrip('/')}/uploads/catalog.pdf" if exists else None,
        }
    ), 200


# ---------------------------------------------------------------------------
# API: send mail
# ---------------------------------------------------------------------------

@app.route("/api/send/<int:lead_id>", methods=["POST"])
def api_send_single(lead_id):
    db = get_db()
    row = db.execute("SELECT * FROM leads WHERE id = ?", (lead_id,)).fetchone()
    if not row:
        return jsonify({"error": "Lead not found"}), 404

    data = request.get_json(silent=True) or {}
    subject = data.get("subject", "Handcrafted Singing Bowl Export Catalog")
    template = data.get(
        "template",
        "<p>Hello {{ownerName}},</p>"
        "<p>We export handcrafted singing bowls and Tibetan wellness items for {{businessName}}.</p>"
        "<p>I have attached our product catalog PDF for your review.</p>"
        "<p>WhatsApp: {{whatsAppNumber}}</p>"
        "<p><a href='{{unsubscribeUrl}}'>Unsubscribe</a></p>",
    )

    html_body = render_template_vars(template, row)
    attachment_path = os.path.join(UPLOAD_DIR, "catalog.pdf")
    if not os.path.exists(attachment_path):
        attachment_path = None

    ok, info = send_email(row["email"], subject, html_body, attachment_path)

    if ok or info == "Demo mode: SMTP is not configured.":
        db.execute("UPDATE leads SET contacted = 'Yes' WHERE id = ?", (lead_id,))
        db.commit()

    status = 200 if ok or info.startswith("Demo mode") else 502
    return (
        jsonify(
            {
                "email": row["email"],
                "success": ok,
                "demo_mode": info == "Demo mode: SMTP is not configured.",
                "message": info,
            }
        ),
        status,
    )


@app.route("/api/send-bulk", methods=["POST"])
def api_send_bulk():
    db = get_db()
    rows = db.execute("SELECT * FROM leads").fetchall()

    data = request.get_json(silent=True) or {}
    subject = data.get("subject", "Handcrafted Singing Bowl Export Catalog")
    template = data.get(
        "template",
        "<p>Hello {{ownerName}},</p>"
        "<p>We export handcrafted singing bowls and Tibetan wellness items for {{businessName}}.</p>"
        "<p>I have attached our product catalog PDF for your review.</p>"
        "<p>WhatsApp: {{whatsAppNumber}}</p>"
        "<p><a href='{{unsubscribeUrl}}'>Unsubscribe</a></p>",
    )

    attachment_path = os.path.join(UPLOAD_DIR, "catalog.pdf")
    if not os.path.exists(attachment_path):
        attachment_path = None

    results = []
    demo_mode = not smtp_configured()
    for row in rows:
        html_body = render_template_vars(template, row)
        ok, info = send_email(row["email"], subject, html_body, attachment_path)
        if ok or info == "Demo mode: SMTP is not configured.":
            db.execute("UPDATE leads SET contacted = 'Yes' WHERE id = ?", (row["id"],))
        results.append({"email": row["email"], "success": ok, "message": info})
    db.commit()

    sent_count = sum(1 for r in results if r["success"] or demo_mode)
    failed_count = len(results) - sent_count

    return (
        jsonify(
            {
                "demo_mode": demo_mode,
                "total": len(results),
                "sent": sent_count,
                "failed": failed_count,
                "results": results,
            }
        ),
        200,
    )


# ---------------------------------------------------------------------------
# API: dashboard stats + CSV export + reset
# ---------------------------------------------------------------------------

@app.route("/api/stats", methods=["GET"])
def api_stats():
    db = get_db()
    total = db.execute("SELECT COUNT(*) c FROM leads").fetchone()["c"]
    contacted = db.execute("SELECT COUNT(*) c FROM leads WHERE contacted = 'Yes'").fetchone()["c"]
    return jsonify(
        {
            "total_leads": total,
            "contacted": contacted,
            "emails_sent": contacted,
            "failed": 0,
            "smtp_configured": smtp_configured(),
        }
    ), 200


@app.route("/api/export-csv", methods=["GET"])
def api_export_csv():
    db = get_db()
    rows = db.execute("SELECT * FROM leads ORDER BY id").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(
        ["id", "business", "owner", "email", "phone", "country", "source", "score", "contacted", "website"]
    )
    for r in rows:
        writer.writerow(
            [r["id"], r["business"], r["owner"], r["email"], r["phone"], r["country"], r["source"], r["score"], r["contacted"], r["website"]]
        )
    csv_data = output.getvalue()
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=leads_export.csv"},
    )


@app.route("/api/reset-database", methods=["POST"])
def api_reset_database():
    db = get_db()
    db.execute("DELETE FROM leads")
    db.commit()
    close_db()
    init_db()
    return jsonify({"message": "Database reset"}), 200


# ---------------------------------------------------------------------------
# Error handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Not found"}), 404
    return e, 404


@app.errorhandler(500)
def server_error(e):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Internal server error"}), 500
    return e, 500


init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5171))
    app.run(host="0.0.0.0", port=port, debug=True)

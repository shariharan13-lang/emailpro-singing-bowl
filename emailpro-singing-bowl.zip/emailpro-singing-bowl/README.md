# EmailPro — Singing Bowl Export & Lead Management System

A Flask + SQLite web app: a Soundtopia-style singing bowl storefront plus an
EmailPro admin dashboard for managing export leads, uploading a PDF catalog,
and sending personalized outreach emails (single or bulk).

## Folder structure

```
emailpro-singing-bowl/
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── templates/
│   ├── base.html
│   ├── store.html
│   └── dashboard.html
├── static/
│   ├── css/style.css
│   └── js/app.js
├── data/
│   └── emailpro.db        (created automatically)
└── uploads/
    └── catalog.pdf         (created after you upload one)
```

## Install & run locally

```bash
cd emailpro-singing-bowl
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then edit .env with your SMTP details (optional)
python app.py
```

Visit **http://127.0.0.1:5171/** for the store, and click
**"Open EmailPro Lead Dashboard →"** (or go straight to `/dashboard`).

The SQLite database is created automatically on first run at
`data/emailpro.db`, seeded with a few sample leads.

## Demo Mode

If any of `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD`,
`MAIL_FROM` are missing from your environment, the app runs in **Demo Mode**:
sending "succeeds" without actually delivering mail, leads are still marked
`contacted = Yes`, and the dashboard clearly labels this as
*"Demo mode: SMTP is not configured."*

## SMTP configuration

Set these environment variables (see `.env.example`):

| Variable | Description |
|---|---|
| `SMTP_HOST` | e.g. `smtp.gmail.com` |
| `SMTP_PORT` | e.g. `587` |
| `SMTP_USERNAME` | your SMTP/Gmail username |
| `SMTP_PASSWORD` | your SMTP password or **Gmail App Password** |
| `MAIL_FROM` | the "From" address |
| `SECRET_KEY` | Flask secret key |
| `WHATSAPP_NUMBER` | optional, used in `{{whatsAppNumber}}` |

For Gmail: enable 2-Step Verification, then create an **App Password** at
https://myaccount.google.com/apppasswords and use that as `SMTP_PASSWORD`.

Never commit real credentials — `.env` is for local use only; on a host like
Render, set these as dashboard environment variables instead.

## API documentation

All endpoints return JSON except `/api/export-csv` (CSV file).

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/leads` | List all leads |
| GET | `/api/leads/<id>` | Get a single lead |
| POST | `/api/leads` | Create a lead (`business`, `email` required) |
| PUT | `/api/leads/<id>` | Update a lead (any subset of fields) |
| DELETE | `/api/leads/<id>` | Delete a lead |
| POST | `/api/upload-catalog` | Upload a PDF (`multipart/form-data`, field `file`) |
| GET | `/api/catalog-status` | Whether a catalog PDF is uploaded |
| POST | `/api/send/<id>` | Send personalized email to one lead |
| POST | `/api/send-bulk` | Send personalized email to all leads |
| GET | `/api/stats` | Dashboard stats (totals, SMTP status) |
| GET | `/api/export-csv` | Download all leads as CSV |
| POST | `/api/reset-database` | Clear leads and reseed sample data |

`POST /api/send/<id>` and `POST /api/send-bulk` accept an optional JSON body:

```json
{
  "subject": "Handcrafted Singing Bowl Export Catalog",
  "template": "<p>Hello {{ownerName}},</p> ..."
}
```

Template variables supported: `{{ownerName}}`, `{{businessName}}`,
`{{whatsAppNumber}}`, `{{unsubscribeUrl}}`.

## Deploying to Render

1. Push this project to a GitHub repository.
2. In Render, create a **new Web Service** from that repo.
3. **Build command:** `pip install -r requirements.txt`
4. **Start command:** `gunicorn app:app`
5. Add environment variables (`SECRET_KEY`, `SMTP_HOST`, `SMTP_PORT`,
   `SMTP_USERNAME`, `SMTP_PASSWORD`, `MAIL_FROM`, `WHATSAPP_NUMBER`) in the
   Render dashboard under **Environment**.
6. Render sets `PORT` automatically — `app.py` already reads
   `os.environ.get("PORT")`, so no changes are needed.

## Security notes

- Uploaded files are validated by extension and saved via
  `werkzeug.utils.secure_filename`, stored as `uploads/catalog.pdf`.
- No credentials are hard-coded; all SMTP config comes from environment
  variables and is never exposed to the frontend.
- User-supplied text is HTML-escaped in the leads table via `escapeHtml()`
  in `static/js/app.js`.
- Basic server-side validation on required lead fields (`business`, `email`).
